package com.example.serving_web_content.controller;
import org.springframework.ui.Model;
import com.example.serving_web_content.model.Empreendimento;
import com.example.serving_web_content.service.EmpreendimentoService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/empreendimentos")
public class EmpreendimentosController {

    private final EmpreendimentoService empreendimentoService;

    // Utilizando a injeção de dependências (DI) //

    @Autowired
    public EmpreendimentosController(EmpreendimentoService empreendimentoService){
        this.empreendimentoService = empreendimentoService;
    }

    // Método LISTAR, que lista o estoque de empreendimentos //

    @GetMapping
    public String listar(@RequestParam(required = false) String pesquisa, Model model){
        List<Empreendimento> resultados = empreendimentoService.listarEmpreendimentos(pesquisa);
        if (pesquisa != null && !pesquisa.trim().isEmpty()) {
            model.addAttribute("termoPesquisa", pesquisa.trim());
        }
        model.addAttribute("empreendimentos", resultados);
        return "empreendimentos/lista";
    }

    // Método NOVO, que inclui um novo empreendimento/UH em estoque //

    @GetMapping("/novo")
    public String novo(Model model){
        model.addAttribute("empreendimento", new Empreendimento());
        return "empreendimentos/form";
    }

    // Método CADASTRAR, que recebe e processa esses dados que o usuário preencheu anteriormente.

    @PostMapping
    public String cadastrar(@Valid @ModelAttribute Empreendimento empreendimento,
                            BindingResult erros, RedirectAttributes ra){
        if (erros.hasErrors()){
            return "empreendimentos/form";
        }
        empreendimentoService.cadastrarEmpreendimento(empreendimento);
        ra.addFlashAttribute("msg", "Empreendimento Cadastrado!");
        return "redirect:/empreendimentos";

    }

    // Método EDIÇÃO, que buscará o objeto correspondente pelo ID e possibilita preencher novamente.

    @GetMapping("/editar/{id}")
    public String abrirEdicao(@PathVariable Long id, Model model){
        Empreendimento empreendimento = empreendimentoService.buscarEmpreendimento(id).get();
        model.addAttribute("empreendimento", empreendimento);
        return "empreendimentos/form";
    }

    // Método ATUALIZAR, que processa a atualização dos dados, e retorna o usuário para a lista de empreendimentos.

    @PutMapping("/{id}")
    public String atualizar(@PathVariable Long id,
                            @Valid @ModelAttribute Empreendimento empreendimento,
                            BindingResult erros,
                            RedirectAttributes ra){
        if (erros.hasErrors()){
            return "empreendimentos/form";
        }

        empreendimentoService.atualizarEmpreendimento(id, empreendimento);
        ra.addFlashAttribute("msg", "Empreendimento Atualizado!");
        return "redirect:/empreendimentos";
    }

    // Método DELETAR, que remove um registro do sistema.

    @GetMapping("/deletar/{id}")
    public String deletar(@PathVariable Long id, RedirectAttributes ra) {
        empreendimentoService.deletarEmpreendimento(id);
        ra.addFlashAttribute("msg", "Empreendimento deletado!");
        return "redirect:/empreendimentos";
    }
}