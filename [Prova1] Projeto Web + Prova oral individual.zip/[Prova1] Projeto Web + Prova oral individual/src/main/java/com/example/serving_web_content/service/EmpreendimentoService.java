package com.example.serving_web_content.service;

import com.example.serving_web_content.model.Empreendimento;
import com.example.serving_web_content.repository.EmpreendimentoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmpreendimentoService {

    public final EmpreendimentoRepository empreendimentoRepository;

    // Injeção de Dependência (DI) via construtor, que é boa prática melhor do que @Autowired.
    public EmpreendimentoService(EmpreendimentoRepository empreendimentoRepository) {
        this.empreendimentoRepository = empreendimentoRepository;
    }

    public List<Empreendimento> listarEmpreendimentos(String termoPesquisa) {
        if (termoPesquisa != null && !termoPesquisa.trim().isEmpty()) {
            return empreendimentoRepository.findByNomeEmpreendimentoContainingIgnoreCase(termoPesquisa);
        }
        return empreendimentoRepository.findAll();
    }

    public Optional<Empreendimento> buscarEmpreendimento(Long id) {
        return empreendimentoRepository.findById(id);
    }

    public Empreendimento cadastrarEmpreendimento(Empreendimento empreendimento) {
        return empreendimentoRepository.save(empreendimento);
    }

    public Empreendimento atualizarEmpreendimento(Long id, Empreendimento empreendimentoAtualizado) {
        Empreendimento empreendimentoExistente = empreendimentoRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Empreendimento não encontrado com o ID: " + id));

        empreendimentoExistente.setNomeEmpreendimento(empreendimentoAtualizado.getNomeEmpreendimento());
        empreendimentoExistente.setData_lancamento(empreendimentoAtualizado.getData_lancamento());
        empreendimentoExistente.setLocalizacao(empreendimentoAtualizado.getLocalizacao());
        empreendimentoExistente.setModulo(empreendimentoAtualizado.getModulo());
        empreendimentoExistente.setUnidades_totais(empreendimentoAtualizado.getUnidades_totais());
        empreendimentoExistente.setUnidades_estoque(empreendimentoAtualizado.getUnidades_estoque());
        empreendimentoExistente.setValor_medio_imovel(empreendimentoAtualizado.getValor_medio_imovel());
        empreendimentoExistente.setValor_medio_avaliacao_imovel(empreendimentoAtualizado.getValor_medio_avaliacao_imovel());
        empreendimentoExistente.setNum_andares(empreendimentoAtualizado.getNum_andares());

        return empreendimentoRepository.save(empreendimentoExistente);
    }

    public void deletarEmpreendimento(Long id) {
        empreendimentoRepository.deleteById(id);
    }

}
