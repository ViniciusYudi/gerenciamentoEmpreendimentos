package com.example.serving_web_content.model;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDate;
import java.math.BigDecimal;

@Entity
@Table(name = "Empreendimento")
public class Empreendimento {

    // ID do Empreendimento
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_empreendimento;

    // Nome do Empreendimento (Obrigatório)
    @NotBlank(message = "O nome do empreendimento não pode estar em branco")
    @Size(max = 150, message = "O nome do empreendimento deve ter no máximo 150 caracteres")
    private String nomeEmpreendimento;

    // Data de Lançamento do Empreendimento (Obrigatório)
    @NotNull(message = "A data de lançamento é obrigatória")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private LocalDate data_lancamento;

    // Localização (Obrigatório)
    @NotBlank(message = "Insira o nome da cidade e do estado onde o emprendimento se encontra.")
    @Size(max = 150, message = "O nome da cidade e do estado devem ter no máximo 150 caracteres")
    private String localizacao;

    // Módulo (Opcional)
    @Min(value = 1, message = "O módulo deve ser no mínimo 1.")
    @Max(value = 9, message = "O módulo deve ser no máximo 9.")
    private Integer modulo;

    // Quantidade Total de UHs (Obrigatório)

    @NotNull(message = "O número de Unidades Habitacionais Totais não pode ser nulo.")
    @Min(value = 1, message = "O número de Unidades Habitacionais Totais deve ser no mínimo 1.")
    private Integer unidades_totais;

    // Quantidade de UHs em Estoque (Obrigatório)

    @NotNull(message = "O número de Unidades Habitacionais em Estoque não pode ser nulo.")
    @Min(value = 0, message = "O número de Unidades Habitacionais em Estoque deve ser no mínimo 0.")
    private Integer unidades_estoque;

    // Valor Médio Imóvel (Obrigatório)

    @NotNull(message = "O valor médio do imóvel não pode ser nulo.")
    @Min(value = 0, message = "O valor médio do imóvel deve ser um valor positivo.")
    private BigDecimal valor_medio_imovel;

    // Valor Médio Avaliação Imóvel (Obrigatório)

    @NotNull(message = "O valor médio de avaliação não pode ser nulo.")
    @Min(value = 0, message = "O valor médio de avaliação do imóvel deve ser um valor positivo.")
    private BigDecimal valor_medio_avaliacao_imovel;

    // Andares (Obrigatório)

    @NotNull(message = "O número de andares do empreendimento não pode ser nulo.")
    @Min(value = 1, message = "O número de andares do empreendimento deve ser de, no mínimo, 1.")
    private Integer num_andares;

    // Construtores da classe //

    // 1. Construtor obrigatório pro JPA //

    public Empreendimento() {
    }

    // 2. Construtor completo //

    public Empreendimento(Long id_empreendimento, String nomeEmpreendimento,
                          LocalDate data_lancamento, String localizacao, Integer modulo,
                          Integer unidades_totais, Integer unidades_estoque,
                          BigDecimal valor_medio_imovel, BigDecimal valor_medio_avaliacao_imovel,
                          Integer num_andares) {

        this.id_empreendimento = id_empreendimento;
        this.nomeEmpreendimento = nomeEmpreendimento;
        this.data_lancamento = data_lancamento;
        this.localizacao = localizacao;
        this.modulo = modulo;
        this.unidades_totais = unidades_totais;
        this.unidades_estoque = unidades_estoque;
        this.valor_medio_imovel = valor_medio_imovel;
        this.valor_medio_avaliacao_imovel = valor_medio_avaliacao_imovel;
        this.num_andares = num_andares;
    }

    // Getters e Setters //

    public Long getId_empreendimento(){
        return id_empreendimento;
    }

    public void setId_empreendimento(Long id_empreendimento){
        this.id_empreendimento = id_empreendimento;
    }

    public String getNomeEmpreendimento() {
        return nomeEmpreendimento;
    }

    public void setNomeEmpreendimento(String nomeEmpreendimento) {
        this.nomeEmpreendimento = nomeEmpreendimento;
    }

    public LocalDate getData_lancamento() {
        return data_lancamento;
    }

    public void setData_lancamento(LocalDate data_lancamento) {
        this.data_lancamento = data_lancamento;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }

    public Integer getModulo() {
        return modulo;
    }

    public void setModulo(Integer modulo) {
        this.modulo = modulo;
    }

    public Integer getUnidades_totais() {
        return unidades_totais;
    }

    public void setUnidades_totais(Integer unidades_totais) {
        this.unidades_totais = unidades_totais;
    }

    public Integer getUnidades_estoque() {
        return unidades_estoque;
    }

    public void setUnidades_estoque(Integer unidades_estoque) {
        this.unidades_estoque = unidades_estoque;
    }

    public BigDecimal getValor_medio_imovel() {
        return valor_medio_imovel;
    }

    public void setValor_medio_imovel(BigDecimal valor_medio_imovel) {
        this.valor_medio_imovel = valor_medio_imovel;
    }

    public BigDecimal getValor_medio_avaliacao_imovel() {
        return valor_medio_avaliacao_imovel;
    }

    public void setValor_medio_avaliacao_imovel(BigDecimal valor_medio_avaliacao_imovel) {
        this.valor_medio_avaliacao_imovel = valor_medio_avaliacao_imovel;
    }

    public Integer getNum_andares() {
        return num_andares;
    }

    public void setNum_andares(Integer num_andares) {
        this.num_andares = num_andares;
    }

}