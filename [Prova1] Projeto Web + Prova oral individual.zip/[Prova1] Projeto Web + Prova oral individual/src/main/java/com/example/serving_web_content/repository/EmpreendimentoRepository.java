package com.example.serving_web_content.repository;

import java.util.List;
import com.example.serving_web_content.model.Empreendimento;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmpreendimentoRepository
        extends JpaRepository<Empreendimento, Long> {

    List<Empreendimento> findByNomeEmpreendimentoContainingIgnoreCase(String termo);
}